#include "mainwindow.h"
#include <QCryptographicHash>
#include <QMessageBox>
#include "networkmanager.h"
#include "ui_mainwindow.h"
#include "ad.h"
#include "adcard.h"

QString hashPassword(QString rawPassword) {
    return QString(QCryptographicHash::hash(rawPassword.toUtf8(), QCryptographicHash::Sha256).toHex());
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(&NetworkManager::instance(), &NetworkManager::loginResponse,
            this, &::MainWindow::handleLoginResponse);
    connect(&NetworkManager::instance(), &NetworkManager::registerResponse,
            this, &::MainWindow::handleRegisterResponse);
    this->setFixedSize(1200,800);
    this->move(400,0);
    ui->App->setCurrentIndex(1);
    ////////////////////////////////////////////////////////////////////////
    QPixmap server_page(":/Images/First_BackGround.png");
    QPalette palette1;
    palette1.setBrush(QPalette::Window, QBrush(server_page));
    ui->Login->setPalette(palette1);
    ui->Login->setAutoFillBackground(true);

    QVBoxLayout *scrollLayout = new QVBoxLayout(ui->scrollAreaWidgetContents);

    for (const Ad &ad : adList) {
        AdCard *card = new AdCard(ad);
        scrollLayout->addWidget(card);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::refreshAds() {
    NetworkManager::instance().sendGetAds();
}

void MainWindow::onGetAdsResponse(bool success, QString message, QVector<Ad> ads) {
    if (!success) return;

    this->adList = ads; // Save to memory

    // Get the layout of the scroll area
    QWidget *container = ui->scrollArea->widget();
    if (!container->layout()) container->setLayout(new QVBoxLayout());
    QLayout *layout = container->layout();

    // Clear old widgets
    QLayoutItem *item;
    while ((item = layout->takeAt(0)) != nullptr) {
        delete item->widget();
        delete item;
    }

    // Add new AdCards
    for (const Ad &ad : adList) {
        if (ad.status == AdStatus::APPROVED) { // Only show approved
            AdCard *card = new AdCard(ad);
            layout->addWidget(card);
        }
    }
    ((QVBoxLayout*)layout)->addStretch(); // Push items up
}

void MainWindow::on_Ok_clicked()
{
    QString user = ui->lineEdit->text();

    QString password = ui->lineEdit_2->text();
    QByteArray hashedData = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedSafePassword = hashedData.toHex();

    if(user.isEmpty() || ui->lineEdit_2->text().isEmpty()) {
        QMessageBox::warning(this, "Error", "Please fill all fields");
        return;
    }

    NetworkManager::instance().sendLogin(user, hashedSafePassword);
}

int clickcount =0;
void MainWindow::on_eye_login_clicked()
{
    if(clickcount==0){
        QPixmap OEyepic(":/Images/open-eye.png");
        ui->eye_login->setIcon(QIcon(OEyepic));
        ui->lineEdit_2->setEchoMode(QLineEdit::Normal);
        clickcount=1;
        return;
    }
    if(clickcount==1){
        QPixmap CEyepic(":/Images/close-eye.png");
        ui->eye_login->setIcon(QIcon(CEyepic));
        ui->lineEdit_2->setEchoMode(QLineEdit::Password);
        clickcount=0;
        return;
    }
}


void MainWindow::on_forgot_pass_clicked()
{
    /*
    QPixmap ResetPass(":/Images/SignUpBack.jpg");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->RestorePass->setPalette(palette);
    ui->RestorePass->setAutoFillBackground(true);*/
    /*QPixmap ResetPass(":/Images/PasswordReset.png");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->RestorePass->setPalette(palette);
    ui->RestorePass->setAutoFillBackground(true);*/
    ui->App->setCurrentIndex(2);
}


void MainWindow::on_SignUp_clicked()
{
    QPixmap ResetPass(":/Images/SignUpBack.jpg");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->SignUpPage->setPalette(palette);
    ui->SignUpPage->setAutoFillBackground(true);
    ui->App->setCurrentIndex(3);
}


void MainWindow::on_Back_clicked()
{
    ui->App->setCurrentIndex(1);
    ui->lineEdit_9->setText("");
    ui->lineEdit_10->setText("");
    ui->lineEdit_11->setText("");
    ui->lineEdit_12->setText("");
    ui->lineEdit_13->setText("");
    ui->lineEdit_14->setText("");
    ui->lineEdit_15->setText("");

}


int clickcount2=0;
void MainWindow::on_eye_signup_clicked()
{
    if(clickcount2==0){
        QPixmap OEyepic(":/Images/open-eye.png");
        ui->eye_signup->setIcon(QIcon(OEyepic));
        ui->lineEdit_13->setEchoMode(QLineEdit::Normal);
        clickcount2=1;
        return;
    }
    if(clickcount2==1){
        QPixmap CEyepic(":/Images/close-eye.png");
        ui->eye_signup->setIcon(QIcon(CEyepic));
        ui->lineEdit_13->setEchoMode(QLineEdit::Password);
        clickcount2=0;
        return;
    }
}


void MainWindow::on_SignupCheck_clicked()
{
    if(ui->lineEdit_9->text().isEmpty()||ui->lineEdit_10->text().isEmpty()||ui->lineEdit_11->text().isEmpty()
        ||ui->lineEdit_12->text().isEmpty()||ui->lineEdit_13->text().isEmpty()||ui->lineEdit_15->text().isEmpty()){
        QMessageBox::warning(this,"Error", "pleas fill in all the blanks\n");
        return;
    }
    QRegularExpression phonenumRegex(R"(\b09\d{9}\b)");
    if (!phonenumRegex.match(ui->lineEdit_11->text()).hasMatch()) {
        QMessageBox::warning(this,"Error", "Invalid phonenumber format\n");
        return;
    }
    QRegularExpression emailRegex(R"((^[^\s@]+@[^\s@]+\.[^\s@]+$))");
    if (!emailRegex.match(ui->lineEdit_12->text()).hasMatch()) {
        QMessageBox::warning(this,"Error", "Invalid email format\n");
        return;
    }
    if(ui->lineEdit_13->text().length()<8){
        QMessageBox::warning(this,"Error", "Password is weak!!\n");
        return;
    }
    if(ui->lineEdit_13->text()!=ui->lineEdit_14->text()){
        QMessageBox::warning(this,"Error", "Password confirmation failed\n");
        return;
    }

    User u;
    u.username = ui->lineEdit_10->text();
    u.passwordHash = hashPassword(ui->lineEdit_13->text()); //
    u.fullName = ui->lineEdit_9->text();
    u.phoneNumber = ui->lineEdit_11->text();
    u.email = ui->lineEdit_12->text();
    u.address = ui->lineEdit_15->text();
    u.walletBalance = 0;
    u.isAdmin = false;


    NetworkManager::instance().sendRegister(u);
}

void MainWindow::handleLoginResponse(bool success, QString message, User user)
{
    if (success) {
        currentUser = user;

        QMessageBox::information(this, "Welcome", "Login Successful!");
        ui->App->setCurrentIndex(4);

    } else {
        QMessageBox::critical(this, "Login Failed", message);
    }
}

void MainWindow::handleRegisterResponse(bool success, QString message)
{
    if (success) {
        QMessageBox::information(this, "Success", message);
        // Switch back to Login view so they can log in
        // Assuming you have a TabWidget or similar for switching between Login/Signup forms
        // ui->tabAuth->setCurrentIndex(0);
        ui->App->setCurrentIndex(4);
    } else {
        QMessageBox::warning(this, "Registration Failed", message);
    }
}

