#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H

#include <QObject>
#include <QTcpSocket>
#include <QDataStream>
#include <QJsonObject>
#include "user.h"
#include "ad.h"

class NetworkManager : public QObject
{
    Q_OBJECT
public:
    static NetworkManager& instance(); // Singleton Access
    void connectToServer();

    void sendLogin(QString username, QString passwordHash);
    void sendRegister(User user);

signals:
    // Signals to update UI when Server replies
    void loginResponse(bool success, QString message, User userData);
    void registerResponse(bool success, QString message);
    void connected();
    void disconnected();
    void sendCreateAd(const Ad &ad);
    void sendGetAds();
    void createAdResponse(bool success, QString message);
    void getAdsResponse(bool success, QString message, QVector<Ad> ads);

private slots:
    void onReadyRead();

private:
    explicit NetworkManager(QObject *parent = nullptr);
    QTcpSocket *socket;
};

#endif // NETWORKMANAGER_H
