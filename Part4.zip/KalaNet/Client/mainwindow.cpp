#include "mainwindow.h"
#include <QCryptographicHash>
#include <QMessageBox>
#include "networkmanager.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(1200,800);
    this->move(400,0);
    ui->App->setCurrentIndex(1);
    ////////////////////////////////////////////////////////////////////////
    QPixmap server_page(":/Images/First_BackGround.png");
    QPalette palette1;
    palette1.setBrush(QPalette::Window, QBrush(server_page));
    ui->Login->setPalette(palette1);
    ui->Login->setAutoFillBackground(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Ok_clicked()
{
    QString user = ui->lineEdit->text();

    QString password = ui->lineEdit_2->text();
    QByteArray hashedData = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedSafePassword = hashedData.toHex();

    if(user.isEmpty() || ui->lineEdit_2->text().isEmpty()) {
        QMessageBox::warning(this, "Error", "Please fill all fields");
        return;
    }

    NetworkManager::instance().sendLogin(user, hashedSafePassword);
}

int clickcount =0;
void MainWindow::on_eye_login_clicked()
{
    if(clickcount==1){
        QPixmap CEyepic(":/Images/close-eye.png");
        ui->eye_login->setIcon(QIcon(CEyepic));
        ui->lineEdit_2->setEchoMode(QLineEdit::Normal);
        clickcount=0;
        return;
    }
    if(clickcount==0){
        QPixmap OEyepic(":/Images/open-eye.png");
        ui->eye_login->setIcon(QIcon(OEyepic));
        ui->lineEdit_2->setEchoMode(QLineEdit::Password);
        clickcount=1;
        return;
    }
}


void MainWindow::on_forgot_pass_clicked()
{
    /*QPixmap ResetPass(":/Images/PasswordReset.png");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->RestorePass->setPalette(palette);
    ui->RestorePass->setAutoFillBackground(true);*/
    ui->App->setCurrentIndex(2);
}


void MainWindow::on_SignUp_clicked()
{
    /*QPixmap ResetPass(":/Images/SignUpBack.png");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->RestorePass->setPalette(palette);
    ui->RestorePass->setAutoFillBackground(true);*/
    ui->App->setCurrentIndex(3);
}

