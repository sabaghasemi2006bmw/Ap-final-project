#ifndef AD_H
#define AD_H

#include <QString>
#include <QJsonObject>
#include <QDataStream>
#include "enums.h"

class Ad {
public:
    Ad();

    QString id;
    QString title;
    QString description;
    QString category;
    long long price; // In Tokens

    // Image is stored as Base64 String for JSON compatibility
    QString imageBase64;

    // Metadata
    QString sellerUsername;
    AdStatus status; // PENDING, APPROVED, SOLD, REJECTED
    QString date;    // Date string

    // Serialization
    QJsonObject toJson() const;
    static Ad fromJson(const QJsonObject &json);

    // Network Streaming
    friend QDataStream &operator<<(QDataStream &out, const Ad &ad);
    friend QDataStream &operator>>(QDataStream &in, Ad &ad);
};

#endif // AD_H
