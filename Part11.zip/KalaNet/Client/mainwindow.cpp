#include "mainwindow.h"
#include <QCryptographicHash>
#include <QMessageBox>
#include <QFileDialog>
#include <QBuffer>
#include <QMessageBox>
#include "networkmanager.h"
#include "ui_mainwindow.h"
#include "ad.h"
#include "adcard.h"

QString hashPassword(QString rawPassword) {
    return QString(QCryptographicHash::hash(rawPassword.toUtf8(), QCryptographicHash::Sha256).toHex());
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    NetworkManager::instance().connectToServer();

    connect(&NetworkManager::instance(), &NetworkManager::loginResponse,
            this, &::MainWindow::handleLoginResponse);
    connect(&NetworkManager::instance(), &NetworkManager::registerResponse,
            this, &::MainWindow::handleRegisterResponse);
    connect(&NetworkManager::instance(), &NetworkManager::updateProfileResponse,
            this, &MainWindow::onUpdateProfileResponse);
    connect(&NetworkManager::instance(), &NetworkManager::createAdResponse,
            this, &MainWindow::onCreateAdResponse);


    this->setFixedSize(1200,800);
    this->move(400,0);
    ui->App->setCurrentIndex(1);
    ////////////////////////////////////////////////////////////////////////
    QPixmap server_page(":/Images/First_BackGround.png");
    QPalette palette1;
    palette1.setBrush(QPalette::Window, QBrush(server_page));
    ui->Login->setPalette(palette1);
    ui->Login->setAutoFillBackground(true);

    QPixmap store_page(":/Images/store_background.jpg");
    QPalette palette2;
    palette2.setBrush(QPalette::Window, QBrush(store_page));
    ui->Store->setPalette(palette2);
    ui->Store->setAutoFillBackground(true);

    QPixmap Ad_Reg_page(":/Images/Ad_registration.png");
    QPalette palette3;
    palette3.setBrush(QPalette::Window, QBrush(Ad_Reg_page));
    ui->Register_Ad->setPalette(palette3);
    ui->Register_Ad->setAutoFillBackground(true);
    //////////////////////////////////////////////////////////////////////////


    QVBoxLayout *scrollLayout = new QVBoxLayout(ui->scrollAreaWidgetContents);

}

void MainWindow::updateAdDisplay()
{
    QWidget *container = ui->scrollAreaWidgetContents;
    if (!container->layout()) container->setLayout(new QVBoxLayout());
    QLayout *layout = container->layout();

    QLayoutItem *item;
    while ((item = layout->takeAt(0)) != nullptr) {
        if (item->widget()) delete item->widget();
        delete item;
    }


    QString searchText = ui->search_le->text().trimmed();

    for (const Ad &ad : adList) {

        if (ad.status != AdStatus::APPROVED) continue;

        bool catMatch = false;
        if(ui->All->isChecked()){
            catMatch = true;
        }
        if(ui->House->isChecked() && ad.category=="House"){
            catMatch = true;
        }
        if(ui->Kitchen->isChecked() && ad.category=="Kitchen"){
            catMatch = true;
        }
        if(ui->DigitalDevices->isChecked() && ad.category=="DigitalDevices"){
            catMatch = true;
        }
        if(ui->Personalthings->isChecked() && ad.category=="Personalthings"){
            catMatch = true;
        }
        if(ui->Vehicles->isChecked() && ad.category=="Vehicles"){
            catMatch = true;
        }

        bool searchMatch = searchText.isEmpty() ||
                           ad.title.contains(searchText, Qt::CaseInsensitive) ||
                           ad.description.contains(searchText, Qt::CaseInsensitive);

        if (catMatch && searchMatch) {
            AdCard *card = new AdCard(ad);
            layout->addWidget(card);
        }
    }

    ((QVBoxLayout*)layout)->addStretch(); // Push items to the top
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::refreshAds() {
    NetworkManager::instance().sendGetAds();
}


void MainWindow::on_Ok_clicked()
{
    QString user = ui->lineEdit->text();

    QString password = ui->lineEdit_2->text();
    QByteArray hashedData = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    QString hashedSafePassword = hashedData.toHex();

    if(user.isEmpty() || ui->lineEdit_2->text().isEmpty()) {
        QMessageBox::warning(this, "Error", "Please fill all fields");
        return;
    }

    NetworkManager::instance().sendLogin(user, hashedSafePassword);
}
int clickcount =0;
void MainWindow::on_eye_login_clicked()
{
    if(clickcount==0){
        QPixmap OEyepic(":/Images/open-eye.png");
        ui->eye_login->setIcon(QIcon(OEyepic));
        ui->lineEdit_2->setEchoMode(QLineEdit::Normal);
        clickcount=1;
        return;
    }
    if(clickcount==1){
        QPixmap CEyepic(":/Images/close-eye.png");
        ui->eye_login->setIcon(QIcon(CEyepic));
        ui->lineEdit_2->setEchoMode(QLineEdit::Password);
        clickcount=0;
        return;
    }
}
void MainWindow::on_forgot_pass_clicked()
{
    /*
    QPixmap ResetPass(":/Images/SignUpBack.jpg");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->RestorePass->setPalette(palette);
    ui->RestorePass->setAutoFillBackground(true);*/
    /*QPixmap ResetPass(":/Images/PasswordReset.png");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->RestorePass->setPalette(palette);
    ui->RestorePass->setAutoFillBackground(true);*/
    ui->App->setCurrentIndex(2);
}
void MainWindow::on_SignUp_clicked()
{
    QPixmap ResetPass(":/Images/SignUpBack.jpg");

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(ResetPass));
    ui->SignUpPage->setPalette(palette);
    ui->SignUpPage->setAutoFillBackground(true);
    ui->App->setCurrentIndex(3);
}
void MainWindow::on_Back_clicked()
{
    ui->App->setCurrentIndex(1);
    ui->lineEdit_9->setText("");
    ui->lineEdit_10->setText("");
    ui->lineEdit_11->setText("");
    ui->lineEdit_12->setText("");
    ui->lineEdit_13->setText("");
    ui->lineEdit_14->setText("");
    ui->lineEdit_15->setText("");

}
int clickcount2=0;
void MainWindow::on_eye_signup_clicked()
{
    if(clickcount2==0){
        QPixmap OEyepic(":/Images/open-eye.png");
        ui->eye_signup->setIcon(QIcon(OEyepic));
        ui->lineEdit_13->setEchoMode(QLineEdit::Normal);
        clickcount2=1;
        return;
    }
    if(clickcount2==1){
        QPixmap CEyepic(":/Images/close-eye.png");
        ui->eye_signup->setIcon(QIcon(CEyepic));
        ui->lineEdit_13->setEchoMode(QLineEdit::Password);
        clickcount2=0;
        return;
    }
}
void MainWindow::on_SignupCheck_clicked()
{
    if(ui->lineEdit_9->text().isEmpty()||ui->lineEdit_10->text().isEmpty()||ui->lineEdit_11->text().isEmpty()
        ||ui->lineEdit_12->text().isEmpty()||ui->lineEdit_13->text().isEmpty()||ui->lineEdit_15->text().isEmpty()){
        QMessageBox::warning(this,"Error", "pleas fill in all the blanks\n");
        return;
    }
    QRegularExpression phonenumRegex(R"(\b09\d{9}\b)");
    if (!phonenumRegex.match(ui->lineEdit_11->text()).hasMatch()) {
        QMessageBox::warning(this,"Error", "Invalid phonenumber format\n");
        return;
    }
    QRegularExpression emailRegex(R"((^[^\s@]+@[^\s@]+\.[^\s@]+$))");
    if (!emailRegex.match(ui->lineEdit_12->text()).hasMatch()) {
        QMessageBox::warning(this,"Error", "Invalid email format\n");
        return;
    }
    if(ui->lineEdit_13->text().length()<8){
        QMessageBox::warning(this,"Error", "Password is weak!!\n");
        return;
    }
    if(ui->lineEdit_13->text()!=ui->lineEdit_14->text()){
        QMessageBox::warning(this,"Error", "Password confirmation failed\n");
        return;
    }

    User u;
    u.username = ui->lineEdit_10->text();
    u.passwordHash = hashPassword(ui->lineEdit_13->text()); //
    u.fullName = ui->lineEdit_9->text();
    u.phoneNumber = ui->lineEdit_11->text();
    u.email = ui->lineEdit_12->text();
    u.address = ui->lineEdit_15->text();
    u.walletBalance = 0;
    u.isAdmin = false;


    NetworkManager::instance().sendRegister(u);
}

void MainWindow::handleLoginResponse(bool success, QString message, User user)
{
    if (success) {
        currentUser = user;

        QMessageBox::information(this, "Welcome", "Login Successful!");
        ui->App->setCurrentIndex(4);

    } else {
        QMessageBox::critical(this, "Login Failed", message);
    }
}
void MainWindow::handleRegisterResponse(bool success, QString message)
{
    if (success) {
        QMessageBox::information(this, "Success", message);

        ui->App->setCurrentIndex(4);
    } else {
        QMessageBox::warning(this, "Registration Failed", message);
    }
}
void MainWindow::onGetAdsResponse(bool success, QString message, QVector<Ad> ads) {
    if (success) {
        this->adList = ads;
        updateAdDisplay();
    }
}

void MainWindow::onUpdateProfileResponse(bool success, QString message)
{
    if (success) {
        QMessageBox::information(this, "Success", "Profile updated successfully!");
        currentUser.fullName = ui->lineEdit_51->text();
        currentUser.phoneNumber = ui->lineEdit_52->text();
        currentUser.email = ui->lineEdit_53->text();
        currentUser.address = ui->lineEdit_55->text();
        ui->App->setCurrentIndex(4);
    } else {
        QMessageBox::critical(this, "Error", "Update failed: " + message);
    }
}

void MainWindow::onCreateAdResponse(bool success, QString message)
{
    ui->NewInform_Ok_2->setEnabled(true); // Re-enable button

    if (success) {
        QMessageBox::information(this, "Success", "Ad submitted! Waiting for Admin approval.");

        // Clear inputs
        ui->Ad_title->clear();
        ui->Ad_price->clear();
        ui->Ad_desc->clear();

        QPixmap pix(":/Images/image-upload.png");
        pix = pix.scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        ui->pushButton_3->setIcon(QIcon(pix));

        selectedAdImageBase64.clear();
    } else {
        QMessageBox::warning(this, "Failed", "Could not register ad: " + message);
    }
}


void MainWindow::on_pushButton_2_clicked()
{
    refreshAds();
}
void MainWindow::on_All_clicked()
{
    refreshAds();
}
void MainWindow::on_House_clicked()
{
    refreshAds();
}
void MainWindow::on_Vehicles_clicked()
{
    refreshAds();
}
void MainWindow::on_DigitalDevices_clicked()
{
    refreshAds();
}
void MainWindow::on_Kitchen_clicked()
{
    refreshAds();
}
void MainWindow::on_Personalthings_clicked()
{
    refreshAds();
}


void MainWindow::on_pushButton_clicked()
{
    ui->App->setCurrentIndex(5);
}


void MainWindow::on_NewInform_Ok_clicked()
{
    if(ui->lineEdit_51->text().isEmpty()||ui->lineEdit_52->text().isEmpty()||ui->lineEdit_53->text().isEmpty()
        ||ui->lineEdit_55->text().isEmpty()){
        QMessageBox::warning(this,"Error", "pleas fill in all the blanks\n");
        return;
    }
    QRegularExpression phonenumRegex(R"(\b09\d{9}\b)");
    if (!phonenumRegex.match(ui->lineEdit_52->text()).hasMatch()) {
        QMessageBox::warning(this,"Error", "Invalid phonenumber format\n");
        return;
    }
    QRegularExpression emailRegex(R"((^[^\s@]+@[^\s@]+\.[^\s@]+$))");
    if (!emailRegex.match(ui->lineEdit_53->text()).hasMatch()) {
        QMessageBox::warning(this,"Error", "Invalid email format\n");
        return;
    }

    User u;
    u.username = currentUser.username;
    u.passwordHash = currentUser.passwordHash; //
    u.fullName = ui->lineEdit_51->text();
    u.phoneNumber = ui->lineEdit_52->text();
    u.email = ui->lineEdit_53->text();
    u.address = ui->lineEdit_55->text();
    u.walletBalance = currentUser.walletBalance;
    u.isAdmin = false;


    NetworkManager::instance().sendUpdateProfile(u);

}


void MainWindow::on_profile_button_clicked()
{
    ui->App->setCurrentIndex(8);

    QPixmap NewInform(":/Images/Personal_Info_back.png");
    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(NewInform));
    ui->Personal_Info->setPalette(palette);
    ui->Personal_Info->setAutoFillBackground(true);

    ui->lineEdit_50->setText(currentUser.username);
    ui->lineEdit_51->setText(currentUser.fullName);
    ui->lineEdit_52->setText(currentUser.phoneNumber);
    ui->lineEdit_53->setText(currentUser.email);
    ui->lineEdit_55->setText(currentUser.address);
    ui->lineEdit_56->setText(QString::number(currentUser.walletBalance));
}


void MainWindow::on_NewInform_Back_clicked()
{
    ui->App->setCurrentIndex(4);
}


void MainWindow::on_pushButton_3_clicked()
{
    // 1. Open File Dialog
    QString fileName = QFileDialog::getOpenFileName(this, "Select Image", "", "Images (*.png *.jpg *.jpeg)");
    if (fileName.isEmpty()) return;

    // 2. Load Image
    QPixmap pix(fileName);
    if (pix.isNull()) {
        QMessageBox::warning(this, "Error", "Failed to load image.");
        return;
    }

    pix = pix.scaled(400, 400, Qt::KeepAspectRatio, Qt::SmoothTransformation);

    ui->pushButton_3->setIcon(QIcon(pix));

    QByteArray bytes;
    QBuffer buffer(&bytes);
    buffer.open(QIODevice::WriteOnly);

    pix.save(&buffer, "JPG", 50);
    selectedAdImageBase64 = bytes.toBase64();
}


void MainWindow::on_NewInform_Ok_2_clicked()
{
    if (ui->Ad_title->text().isEmpty() ||
        ui->Ad_price->text().isEmpty() ||
        selectedAdImageBase64.isEmpty()||
        ui->comboBox->currentText().isEmpty()) {
        QMessageBox::warning(this, "Missing Info", "Please fill title, price, and select an image.");
        return;
    }

    // 2. Create Ad Object
    Ad newAd;
    newAd.title = ui->Ad_title->text();
    newAd.price = ui->Ad_price->text().toLongLong();
    newAd.description = ui->Ad_desc->toPlainText();
    newAd.category = ui->comboBox->currentText();
    newAd.imageBase64 = selectedAdImageBase64;
    newAd.sellerUsername = currentUser.username;
    newAd.status = AdStatus::PENDING;
    selectedAdImageBase64 = "";
    qDebug() << "Received Create Ad Request from:" << newAd.sellerUsername;

    // Try to save it to the database
    qDebug() << newAd.date;
    qDebug() << newAd.category;
    qDebug() << newAd.imageBase64;
    // 3. Send to Server
    NetworkManager::instance().sendCreateAd(newAd);

    // Optional: Disable button to prevent double-click
    ui->NewInform_Ok_2->setEnabled(false);
}

