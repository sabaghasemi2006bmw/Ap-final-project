#include "databasemanager.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <QUuid>

DatabaseManager::DatabaseManager(QObject *parent) : QObject(parent) {
    loadData();
    loadAds();

}


//Users
void DatabaseManager::loadData() {
    QMutexLocker locker(&mutex); // Lock so no one edits while we load

    QFile file(USERS_FILE);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "No users file found. Creating new database.";
        return;
    }

    QByteArray data = file.readAll();
    QJsonDocument doc = QJsonDocument::fromJson(data);
    QJsonArray array = doc.array();

    users.clear();
    for (const QJsonValue &val : array) {
        users.append(User::fromJson(val.toObject()));
    }
    file.close();
    qDebug() << "Loaded" << users.size() << "users.";
}

void DatabaseManager::saveData() {
    QMutexLocker locker(&mutex);

    QJsonArray array;
    for (const User &u : users) {
        array.append(u.toJson());
    }

    QJsonDocument doc(array);
    QFile file(USERS_FILE);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
    }
}

bool DatabaseManager::registerUser(const User &newUser) {
    QMutexLocker locker(&mutex);

    // Check if username already exists
    for (const User &u : users) {
        if (u.username == newUser.username) return false;
    }

    users.append(newUser);
    QJsonArray array;
    for (const User &u : users) array.append(u.toJson());
    QJsonDocument doc(array);
    QFile file(USERS_FILE);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
    }

    return true;
}

User* DatabaseManager::loginUser(QString username, QString passwordHash) {
    QMutexLocker locker(&mutex);


    for (int i = 0; i < users.size(); ++i) {
        if (users[i].username == username && users[i].passwordHash == passwordHash) {
            return &users[i];
        }
    }
    return nullptr;
}

//Ads
void DatabaseManager::loadAds() {
    QMutexLocker locker(&mutex);
    QFile file(ADS_FILE);
    if (!file.open(QIODevice::ReadOnly)) return;

    QJsonArray array = QJsonDocument::fromJson(file.readAll()).array();
    ads.clear();
    for (const QJsonValue &val : array) {
        ads.append(Ad::fromJson(val.toObject()));
    }
    file.close();
}

void DatabaseManager::saveAds() {

    QMutexLocker locker(&mutex);

    QJsonArray array;
    for (const Ad &a :ads) {
        array.append(a.toJson());
    }

    QJsonDocument doc(array);
    QFile file(ADS_FILE);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
    }

}

bool DatabaseManager::createAd(Ad &newAd) {
    QMutexLocker locker(&mutex);

    for (const Ad &existingAd : ads) {
        if (existingAd.sellerUsername == newAd.sellerUsername &&
            existingAd.title == newAd.title &&
            existingAd.description == newAd.description &&
            existingAd.status != AdStatus::SOLD)
        {

            return false;
        }
    }

    newAd.id = QUuid::createUuid().toString(QUuid::Id128);
    newAd.status = AdStatus::PENDING;

    ads.append(newAd);
    mutex.unlock();
    saveAds();
    mutex.lock();
    return true;
}

QVector<Ad> DatabaseManager::getAllAds() {
    QMutexLocker locker(&mutex);
    return ads;
}

QVector<Ad> DatabaseManager::getApprovedAds() {
    QMutexLocker locker(&mutex);
    QVector<Ad> result;
    for(const Ad &ad : ads) {
        if(ad.status == AdStatus::APPROVED) result.append(ad);
    }
    return result;
}

void DatabaseManager::updateAdStatus(QString adId, AdStatus newStatus) {
    QMutexLocker locker(&mutex);
    for(Ad &ad : ads) {
        if(ad.id == adId) {
            ad.status = newStatus;
            break;
        }
    }
    mutex.unlock();
    saveAds();
    mutex.lock();

}

bool DatabaseManager::updateUser(const User &updatedUser) {
    QMutexLocker locker(&mutex);

    for (int i = 0; i < users.size(); ++i) {
        if (users[i].username == updatedUser.username) {
            // Update editable fields
            users[i].fullName = updatedUser.fullName;
            users[i].phoneNumber = updatedUser.phoneNumber;
            users[i].email = updatedUser.email;
            users[i].address = updatedUser.address;
            users[i].passwordHash = updatedUser.passwordHash;
            users[i].walletBalance = updatedUser.walletBalance;
            locker.unlock();
            saveData();

            return true;
        }
    }

    return false;
}
