#ifndef MYSERVER_H
#define MYSERVER_H

class MyServer
{
public:
    MyServer();
};

#endif // MYSERVER_H
