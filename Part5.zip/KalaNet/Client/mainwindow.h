#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "networkmanager.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_Ok_clicked();

    void on_eye_login_clicked();

    void on_forgot_pass_clicked();

    void on_SignUp_clicked();

    void on_Back_clicked();

    void on_eye_signup_clicked();

    void on_SignupCheck_clicked();

    void handleLoginResponse(bool success, QString message, User user);

    void handleRegisterResponse(bool success, QString message);

private:
    Ui::MainWindow *ui;
    User currentUser;
};
#endif // MAINWINDOW_H
