#include "networkmanager.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonDocument>
#include <QCryptographicHash>

NetworkManager& NetworkManager::instance() {
    static NetworkManager _instance;
    return _instance;
}

NetworkManager::NetworkManager(QObject *parent) : QObject(parent) {
    socket = new QTcpSocket(this);
    connect(socket, &QTcpSocket::readyRead, this, &NetworkManager::onReadyRead);
    connect(socket, &QTcpSocket::connected, this, &NetworkManager::connected);
    connect(socket, &QTcpSocket::disconnected, this, &NetworkManager::disconnected);
}

void NetworkManager::connectToServer() {
    // Connect to Localhost (127.0.0.1) on Port 1234
    socket->connectToHost("127.0.0.1", 1234);
}

void NetworkManager::sendLogin(QString username, QString passwordHash) {
    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);

    out << (qint32)RequestType::LOGIN;
    out << username << passwordHash;

    socket->write(packet);
}

void NetworkManager::sendRegister(User user) {
    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);

    out << (qint32)RequestType::REGISTER;
    out << user; // Uses the operator<< from Common

    socket->write(packet);
}

void NetworkManager::sendCreateAd(const Ad &ad) {
    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);

    out << (qint32)RequestType::CREATE_AD; // Send Type
    out << ad;                             // Send Ad Object (uses operator<< from common)

    socket->write(packet);
}

void NetworkManager::sendGetAds() {
    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);

    out << (qint32)RequestType::GET_ALL_ADS; // Just send the type

    socket->write(packet);
}


void NetworkManager::onReadyRead() {
    QDataStream in(socket);
    in.setVersion(QDataStream::Qt_5_15);

    while(true) {
        if (socket->bytesAvailable() < (int)sizeof(qint32)) break;

        // Read Packet Header
        qint32 typeInt;
        in >> typeInt;
        RequestType type = static_cast<RequestType>(typeInt);

        bool success;
        QString message;
        QByteArray jsonData;

        in >> success >> message >> jsonData;
        QJsonObject data = QJsonDocument::fromJson(jsonData).object();

        switch (type) {
        case RequestType::LOGIN:
            // If success, we also get the user object back
            emit loginResponse(success, message, success ? User::fromJson(data) : User());
            break;
        case RequestType::REGISTER:
            emit registerResponse(success, message);
            break;
        case RequestType::CREATE_AD:
            emit createAdResponse(success, message);
            break;

        case RequestType::GET_ALL_ADS: {
            QVector<Ad> resultAds;
            if (success) {
                QJsonArray adsArray = data["ads"].toArray();
                for(const QJsonValue &val : adsArray) {
                    resultAds.append(Ad::fromJson(val.toObject()));
                }
            }
            emit getAdsResponse(success, message, resultAds);
            break;
        }
        default:
            break;
        }
    }
}
