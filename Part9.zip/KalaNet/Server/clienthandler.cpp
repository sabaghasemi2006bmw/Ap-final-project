#include "clienthandler.h"
#include "qjsonarray.h"
#include <QDataStream>
#include <QJsonObject>
#include <QJsonDocument>

ClientHandler::ClientHandler(qintptr socketDescriptor, DatabaseManager *db, QObject *parent)
    : QThread(parent), socketDescriptor(socketDescriptor), db(db)
{
}

void ClientHandler::run() {
    socket = new QTcpSocket();
    if (!socket->setSocketDescriptor(socketDescriptor)) {
        emit error(socket->error());
        return;
    }

    connect(socket, &QTcpSocket::readyRead, this, &ClientHandler::onReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &ClientHandler::onDisconnected);

    // Keep the thread alive to listen for signals
    exec();
}

void ClientHandler::onReadyRead() {
    QDataStream in(socket);
    in.setVersion(QDataStream::Qt_5_15);

    // If we don't have enough data for the "Type" (int), return and wait for more
    if (socket->bytesAvailable() < (int)sizeof(qint32)) return;

    // Read the Header (What does the client want?)
    qint32 typeInt;
    in >> typeInt;
    RequestType type = static_cast<RequestType>(typeInt);

    switch (type) {
    case RequestType::LOGIN:
        handleLogin(in);
        break;
    case RequestType::REGISTER:
        handleRegister(in);
        break;
    case RequestType::CREATE_AD:
        handleCreateAd(in);
        break;
    case RequestType::GET_ALL_ADS:
        handleGetAds(in);
        break;
    case RequestType::UPDATE_PROFILE:
        handleUpdateProfile(in);
        break;
    // We will add GET_ADS, BUY_ITEM, etc. here later
    default:
        break;
    }
}

// Implement these functions:

void ClientHandler::handleCreateAd(QDataStream &in) {
    Ad newAd;
    in >> newAd; // Receive the Ad object

    db->createAd(newAd); // Save it

    sendResponse(RequestType::CREATE_AD, true, "Ad submitted for review!");
}

void ClientHandler::handleGetAds(QDataStream &in) {
    // Client asking for ads.
    // Usually, they want APPROVED ads.
    QVector<Ad> ads = db->getApprovedAds();

    QJsonArray adArray;
    for(const Ad &a : ads) adArray.append(a.toJson());

    // Send list back
    sendResponse(RequestType::GET_ALL_ADS, true, "OK", QJsonObject{{"ads", adArray}});
}

void ClientHandler::handleRegister(QDataStream &in) {
    User newUser;
    in >> newUser;

    bool success = db->registerUser(newUser);

    if (success) {
        sendResponse(RequestType::REGISTER, true, "Registration Successful!");
    } else {
        sendResponse(RequestType::REGISTER, false, "Username already exists.");
    }
}

void ClientHandler::handleLogin(QDataStream &in) {
    QString username, passwordHash;
    in >> username >> passwordHash;

    User* user = db->loginUser(username, passwordHash);

    if (user) {
        // Send back success + the full user profile (so Client knows wallet balance/Address)
        sendResponse(RequestType::LOGIN, true, "Welcome back!", user->toJson());
    } else {
        sendResponse(RequestType::LOGIN, false, "Invalid username or password.");
    }
}

void ClientHandler::handleUpdateProfile(QDataStream &in) {
    User updatedUser;
    in >> updatedUser;

    bool success = db->updateUser(updatedUser);

    if (success) {
        sendResponse(RequestType::UPDATE_PROFILE, true, "Profile updated!");
    } else {
        sendResponse(RequestType::UPDATE_PROFILE, false, "Could not update profile.");
    }
}

void ClientHandler::sendResponse(RequestType type, bool success, const QString &message, const QJsonObject &data) {
    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);

    // Packet Structure: [Type] [Success] [Message] [Data(JSON)]
    out << (qint32)type;
    out << success;
    out << message;
    out << QJsonDocument(data).toJson();

    socket->write(packet);
    socket->flush();
}

void ClientHandler::onDisconnected() {
    socket->deleteLater();
    exit(0);
}
