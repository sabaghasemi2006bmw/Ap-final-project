#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QVector>
#include <QMap>
#include <QMutex>
#include "user.h" // From Common

class DatabaseManager : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseManager(QObject *parent = nullptr);

    void loadData();
    void saveData();

    bool registerUser(const User &newUser); // Returns false if username exists
    User* loginUser(QString username, QString passwordHash);

    int getUserCount() const { return users.size(); }

private:
    QVector<User> users;

    // Thread safety: Multiple clients might try to register at once!
    QMutex mutex;

    const QString USERS_FILE = "users.json";
};

#endif // DATABASEMANAGER_H
