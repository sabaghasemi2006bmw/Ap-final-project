#include "clienthandler.h"
#include "qjsonarray.h"
#include <QDataStream>
#include <QJsonObject>
#include <QJsonDocument>

ClientHandler::ClientHandler(qintptr socketDescriptor, DatabaseManager *db, QObject *parent)
    : QThread(parent), socketDescriptor(socketDescriptor), db(db)
{
}

void ClientHandler::run() {
    socket = new QTcpSocket();
    if (!socket->setSocketDescriptor(socketDescriptor)) {
        emit error(socket->error());
        return;
    }

    connect(socket, &QTcpSocket::readyRead, this, &ClientHandler::onReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &ClientHandler::onDisconnected);

    // Keep the thread alive to listen for signals
    exec();
}

void ClientHandler::onReadyRead() {
    QDataStream in(socket);
    in.setVersion(QDataStream::Qt_5_15);

    // Infinite loop to process multiple packets arriving at once
    while (true) {
        // Step 1: Read the Header (Size)
        if (blockSize == 0) {
            // We need at least 4 bytes to read the size integer
            if (socket->bytesAvailable() < (qint64)sizeof(qint32))
                return; // Wait for more data

            in >> blockSize;
        }

        // Step 2: Read the Body
        if (socket->bytesAvailable() < blockSize)
            return; // Wait for the rest of the packet to arrive

        // Step 3: Process the Full Packet
        qint32 typeInt;
        in >> typeInt;
        RequestType type = static_cast<RequestType>(typeInt);

        switch (type) {
        case RequestType::LOGIN:    handleLogin(in); break;
        case RequestType::REGISTER: handleRegister(in); break;
        case RequestType::CREATE_AD: handleCreateAd(in); break;
        case RequestType::GET_ALL_ADS: handleGetAds(in); break;
        case RequestType::UPDATE_PROFILE: handleUpdateProfile(in); break;
        default: break;
        }

        // Step 4: Reset for the next packet
        blockSize = 0;
    }
}

// Implement these functions:

void ClientHandler::handleCreateAd(QDataStream &in) {

    Ad newAd;
    in >> newAd;

    qDebug() << "Received Create Ad Request from:" << newAd.sellerUsername;

    // Try to save it to the database

    bool success = db->createAd(newAd);

    if (success) {
        //  Ad is saved as Pending
        sendResponse(RequestType::CREATE_AD, true, "Ad created successfully! It is now waiting for Admin approval.");
    } else {
        //  Handle duplicate error
        sendResponse(RequestType::CREATE_AD, false, "Error: You have already posted an identical ad.");
    }
}

void ClientHandler::handleGetAds(QDataStream &in) {
    // Client asking for ads.
    // Usually, they want APPROVED ads.
    qDebug() << "Sending All Ads";

    QVector<Ad> ads = db->getApprovedAds();

    QJsonArray adArray;
    for(const Ad &a : ads) adArray.append(a.toJson());

    // Send list back
    qDebug() << "Sent";
    sendResponse(RequestType::GET_ALL_ADS, true, "OK", QJsonObject{{"ads", adArray}});
    qDebug() << "finish sending";
}

void ClientHandler::handleRegister(QDataStream &in) {
    User newUser;
    in >> newUser;

    bool success = db->registerUser(newUser);

    if (success) {
        sendResponse(RequestType::REGISTER, true, "Registration Successful!");
    } else {
        sendResponse(RequestType::REGISTER, false, "Username already exists.");
    }
}

void ClientHandler::handleLogin(QDataStream &in) {
    QString username, passwordHash;
    in >> username >> passwordHash;

    User* user = db->loginUser(username, passwordHash);

    if (user) {
        // Send back success + the full user profile (so Client knows wallet balance/Address)
        sendResponse(RequestType::LOGIN, true, "Welcome back!", user->toJson());
    } else {
        sendResponse(RequestType::LOGIN, false, "Invalid username or password.");
    }
}

void ClientHandler::handleUpdateProfile(QDataStream &in) {
    User updatedUser;
    in >> updatedUser;

    bool success = db->updateUser(updatedUser);

    if (success) {
        sendResponse(RequestType::UPDATE_PROFILE, true, "Profile updated!");
    } else {
        sendResponse(RequestType::UPDATE_PROFILE, false, "Could not update profile.");
    }
}

void ClientHandler::sendResponse(RequestType type, bool success, const QString &message, const QJsonObject &data) {
    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);

    // 1. Reserve 4 bytes for the Size Header
    out << (qint32)0;

    // 2. Write the Standard Payload
    out << (qint32)type;
    out << success;
    out << message;

    // Write JSON Data (as a byte array to be safe)
    out << QJsonDocument(data).toJson(QJsonDocument::Compact);

    // 3. Jump back to the start and write the actual size
    out.device()->seek(0);
    out << (qint32)(packet.size() - sizeof(qint32));

    // 4. Send
    socket->write(packet);
    socket->flush();
}

void ClientHandler::onDisconnected() {
    socket->deleteLater();
    exit(0);
}
